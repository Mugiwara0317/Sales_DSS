


<?php
session_start();
// Security check: if no user session exists, kick back to login
if (!isset($_SESSION['user'])) {
    header("Location: login.html");
    exit();
}

include 'db_config.php'; // Ensure you have your database connection file

// 1. Total Revenue
$rev_res = $conn->query("SELECT SUM(total_amount) as total FROM sales_records");
$row_rev = $rev_res->fetch_assoc();
$total_revenue = $row_rev['total'] ?? 0;

// 2. Total Sales (Transaction Count)
$sales_res = $conn->query("SELECT COUNT(*) as total FROM sales_records");
$total_sales_count = $sales_res->fetch_assoc()['total'] ?? 0;

// 3. Best-Selling Product (Brand with most quantity sold)
$best_res = $conn->query("SELECT brand, SUM(quantity) as qty FROM sales_records GROUP BY brand ORDER BY qty DESC LIMIT 1");
$best_product = $best_res->fetch_assoc()['brand'] ?? "N/A";

// 4. Slow-Moving Brands (Brand with least quantity sold)
$slow_res = $conn->query("SELECT brand, SUM(quantity) as qty FROM sales_records GROUP BY brand ORDER BY qty ASC LIMIT 1");
$slow_brand = $slow_res->fetch_assoc()['brand'] ?? "N/A";

// 5. Low Stock Items (First item found with stock < 10)
// Note: Assuming your inventory table is named 'inventory'
// Find the first item where stock is less than or equal to reorder_level (defaulting to 10)
$low_stock_res = $conn->query("SELECT brand FROM inventory WHERE stock_quantity <= COALESCE(reorder_level, 10) LIMIT 1");
$low_stock_item = $low_stock_res->fetch_assoc()['brand'] ?? "NONE";

// Group by brand to get the TOTAL stock across all entries for that brand
$low_stock_query = "SELECT brand, SUM(stock_quantity) as total_stock 
                    FROM inventory 
                    GROUP BY brand 
                    HAVING total_stock <= 10 
                    LIMIT 1";
$low_stock_res = $conn->query($low_stock_query);
$low_stock_item = $low_stock_res->fetch_assoc()['brand'] ?? "NONE";


// 1. Daily Sales (Current Week)
$daily_res = $conn->query("SELECT DAYNAME(transaction_date) as day, SUM(quantity) as qty 
                           FROM sales_records 
                           WHERE YEARWEEK(transaction_date) = YEARWEEK(NOW())
                           GROUP BY day ORDER BY FIELD(day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')");
$daily_labels = []; $daily_data = [];
while($r = $daily_res->fetch_assoc()) { $daily_labels[] = $r['day']; $daily_data[] = $r['qty']; }

// 2. Monthly Sales (Current Year)
$monthly_res = $conn->query("SELECT DATE_FORMAT(transaction_date, '%b') as month, SUM(quantity) as qty 
                             FROM sales_records 
                             WHERE YEAR(transaction_date) = YEAR(NOW())
                             GROUP BY month ORDER BY MONTH(transaction_date)");
$monthly_labels = []; $monthly_data = [];
while($r = $monthly_res->fetch_assoc()) { $monthly_labels[] = $r['month']; $monthly_data[] = $r['qty']; }

// 3. Yearly Sales Trend
$yearly_res = $conn->query("SELECT YEAR(transaction_date) as year, SUM(quantity) as qty 
                            FROM sales_records GROUP BY year ORDER BY year ASC");
$yearly_labels = []; $yearly_data = [];
while($r = $yearly_res->fetch_assoc()) { $yearly_labels[] = $r['year']; $yearly_data[] = $r['qty']; }

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shirt To Go - Dashboard</title>
    <link rel="stylesheet" href="dashboard-style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

    <header class="main-header">
        <div class="header-container">
            <div class="logo-section">
                <img src="images/logo.png" alt="Logo" class="nav-logo">
            </div>
            <nav class="nav-links">
    <a href="dashboard.php">Dashboard</a>
    <a href="sales_records.php">Sales Records</a>
    <a href="inventory.php">Inventory</a>
   <a href="reports.php">Reports</a>
</nav>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </header>

    <main class="dashboard-content">
        <div class="page-title">
            <h1>Dashboard</h1>
            <p>Sales overview and key metrics</p>
        </div>

       <div class="kpi-grid">
    <div class="card">
        <h3>Total Revenue</h3>
        <p class="value">₱<?php echo number_format($total_revenue / 1000, 1); ?>K</p>
    </div>

    <div class="card">
        <h3>Total Sales</h3>
        <p class="value"><?php echo number_format($total_sales_count); ?></p>
    </div>

    <div class="card">
        <h3>Best-Selling Product</h3>
        <p class="value product"><?php echo strtoupper($best_product); ?></p>
    </div>

    <div class="card">
        <h3>Slow-moving brands</h3>
        <p class="value brand"><?php echo strtoupper($slow_brand); ?></p>
    </div>

    <div class="card">
        <h3>Low Stock Items</h3>
        <p class="value product" style="color: #d9534f;"><?php echo strtoupper($low_stock_item); ?></p>
    </div>
</div>

        <div class="sales-trend-section">
            <h2 class="section-title">Sales Trend Overview</h2>
            
            <div class="charts-grid">
                <div class="chart-card">
                    <h3>Daily Sales Trend</h3>
                    <canvas id="dailySalesChart"></canvas>
                </div>

                <div class="chart-card">
                    <h3>Monthly Sales Trend</h3>
                    <canvas id="monthlySalesChart"></canvas>
                </div>

                <div class="chart-card">
                    <h3>Yearly Sales Trend</h3>
                    <canvas id="yearlySalesChart"></canvas>
                </div>

                
            </div>
            <div class="analytics-secondary-section">
    <div class="charts-grid-secondary">
        <div class="chart-card">
            <h3>Weekly Sales & Revenue</h3>
            <div style="height: 250px;">
                <canvas id="weeklyRevenueChart"></canvas>
            </div>
        </div>

        <div class="chart-card">
            <h3>Sales Channel Overview</h3>
            <div style="height: 250px;">
                <canvas id="channelPieChart"></canvas>
            </div>
        </div>

       
        </div>
 <div class="inventory-insights-section">
    <div class="bottom-grid">
        
        <div class="inventory-card">
    <h2 class="section-title-alt">Brand Inventory / Stock Status</h2>
    <div class="brand-grid-container" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;">
        <?php 
        // 2. Fetch data grouped by brand to prevent duplicates like 'Dannon'
        $inv_res = $conn->query("SELECT brand, SUM(stock_quantity) as total_stock FROM inventory GROUP BY brand");

        while($row = $inv_res->fetch_assoc()): 
            // 3. Logic: If total stock is 10 or less, it's Low Stock
            $isLow = ($row['total_stock'] <= 10); 
        ?>
            <div class="brand-card" style="background: white; padding: 15px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); position: relative;">
                <span class="badge <?php echo $isLow ? 'low-stock' : 'in-stock'; ?>" style="position: absolute; top: 10px; right: 10px; font-size: 0.7rem;">
                    <?php echo $isLow ? 'Low Stock' : 'In Stock'; ?>
                </span>
                <h3 style="color: #1a0a54; margin-bottom: 5px; font-size: 1.1rem;"><?php echo htmlspecialchars($row['brand']); ?></h3>
                <p style="color: #8b80f9; font-size: 0.85rem; margin: 0;">Stock Qty: <strong><?php echo $row['total_stock']; ?> units</strong></p>
            </div>
        <?php endwhile; ?>
    </div>
</div>

        <div class="insights-card">
            <h2 class="section-title-center">System Insights</h2>
            
            <div class="insight-item">
                <h4>Increase Inventory</h4>
                <p>Polo Shirts due to high demand in Retail channel (40%).</p>
            </div>

            <div class="insight-item">
                <h4>Restock Alert</h4>
                <p>Lifeline, Dannon, and AJZ brands are low on stock.</p>
            </div>

            <div class="insight-item">
                <h4>Channel Focus</h4>
                <p>Expand online presence (Lazada, Shopee, TikTok Shop).</p>
            </div>

            <div class="insight-item">
                <h4>Optimize Wholesale</h4>
                <p>Wholesale channel at 20% - negotiate better bulk deals.</p>
            </div>
    </div>
</div>
    </div>
</div>
        </div>
    </main>

    <script>
        // Global configuration for all charts
        const chartOptions = {
            responsive: true,
            maintainAspectRatio: true,
            plugins: { 
                legend: { display: false } 
            },
            scales: {
                y: { 
                    beginAtZero: true, 
                    grid: { borderDash: [2, 2] } 
                },
                x: { 
                    grid: { display: false } 
                }
            }
        };

        // Daily Chart
new Chart(document.getElementById('dailySalesChart'), {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($daily_labels); ?>,
        datasets: [{ data: <?php echo json_encode($daily_data); ?>, backgroundColor: '#1a1f36' }]
    },
    options: chartOptions
});

// Monthly Chart
new Chart(document.getElementById('monthlySalesChart'), {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($monthly_labels); ?>,
        datasets: [{ data: <?php echo json_encode($monthly_data); ?>, backgroundColor: '#445069' }]
    },
    options: chartOptions
});

// Yearly Chart
new Chart(document.getElementById('yearlySalesChart'), {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($yearly_labels); ?>,
        datasets: [{ data: <?php echo json_encode($yearly_data); ?>, backgroundColor: '#6b728e' }]
    },
    options: chartOptions
});

        // Monthly Chart Data
        new Chart(document.getElementById('monthlySalesChart'), {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    data: [4000, 3000, 5500, 4200, 5800, 6200],
                    backgroundColor: '#445069'
                }]
            },
            options: chartOptions
        });

        // Yearly Chart Data
        new Chart(document.getElementById('yearlySalesChart'), {
            type: 'bar',
            data: {
                labels: ['2019', '2020', '2021', '2022', '2023', '2024'],
                datasets: [{
                    data: [35000, 42000, 58000, 65000, 72000, 85000],
                    backgroundColor: '#6b728e'
                }]
            },
            options: chartOptions
        });

        // Weekly Sales & Revenue Line Chart
new Chart(document.getElementById('weeklyRevenueChart'), {
    type: 'line',
    data: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        datasets: [
            {
                label: 'Revenue',
                data: [12000, 10000, 45000, 20000, 25000, 20000],
                borderColor: '#4a3aff',
                backgroundColor: 'transparent',
                tension: 0.4,
                pointBackgroundColor: '#fff',
                pointBorderColor: '#4a3aff',
                pointBorderWidth: 2
            },
            {
                label: 'Sales',
                data: [5000, 4000, 10000, 6000, 7000, 5000],
                borderColor: '#1a1f36',
                backgroundColor: 'transparent',
                tension: 0.4,
                pointBackgroundColor: '#fff',
                pointBorderColor: '#1a1f36',
                pointBorderWidth: 2
            }
        ]
    },
    options: {
        ...chartOptions, // Reuse your existing global options
        plugins: { legend: { display: true, position: 'bottom' } }
    }
});

// Sales Channel Pie Chart
new Chart(document.getElementById('channelPieChart'), {
    type: 'pie',
    data: {
        labels: ['Retail 40%', 'Wholesale 20%', 'Lazada 15%', 'Shopee 15%', 'TikTok Shop 10%'],
        datasets: [{
            data: [40, 20, 15, 15, 10],
            backgroundColor: ['#1a1f36', '#445069', '#6b728e', '#9097b1', '#bdc3d6'],
            borderWidth: 2,
            borderColor: '#ffffff'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { position: 'right', labels: { boxWidth: 15, padding: 20 } }
        }
    }
});
    </script>

</body>
</html>