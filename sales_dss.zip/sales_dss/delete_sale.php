<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.html");
    exit();
}

include 'db_config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Use a prepared statement for security
    $stmt = $conn->prepare("DELETE FROM sales_records WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        // Redirect back with a success status
        header("Location: sales_records.php?status=deleted");
    } else {
        echo "Error deleting record: " . $conn->error;
    }
    $stmt->close();
}
$conn->close();
?>