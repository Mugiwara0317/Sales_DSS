<?php
include 'db_config.php';

// 1. Get the record ID from the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM sales_records WHERE id = $id");
    $data = $result->fetch_assoc();
}

// 2. Handle the Update Request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $channel = $_POST['channel'];
    $brand = $_POST['brand'];
    $size = $_POST['size']; // Capture the new size
    $qty = $_POST['quantity'];
    $price = $_POST['unit_price'];
    $total = $qty * $price;

    // Updated SQL with size=?
    $sql = "UPDATE sales_records SET channel=?, brand=?, size=?, quantity=?, unit_price=?, total_amount=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssiidi", $channel, $brand, $size, $qty, $price, $total, $id);

    if ($stmt->execute()) {
        header("Location: sales_records.php?status=updated");
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Sale - <?php echo $data['transaction_id']; ?></title>
    <link rel="stylesheet" href="dashboard-style.css">
</head>
<body>
    <div class="modal-content" style="margin: 50px auto; display: block; position: relative;">
        <h2>Edit Transaction: <?php echo $data['transaction_id']; ?></h2>
        
        <form method="POST">
            <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
            
            <label>Sales Channel</label>
            <select name="channel">
                <option <?php if($data['channel'] == 'Tiktok') echo 'selected'; ?>>Tiktok</option>
                <option <?php if($data['channel'] == 'Wholesale') echo 'selected'; ?>>Wholesale</option>
                <option <?php if($data['channel'] == 'Retail') echo 'selected'; ?>>Retail</option>
            </select>

            <label>Brand</label>
<select name="brand">
    <?php
    $brands = ['Yalex', 'Softex', 'Gildan', 'ARTIX', 'LIFELINE', 'BLUE CORNER', 'Kentucky'];
    foreach ($brands as $b) {
        $selected = ($data['brand'] == $b) ? 'selected' : '';
        echo "<option value='$b' $selected>$b</option>";
    }
    ?>
</select>

            <label>Quantity</label>
            <input type="number" name="quantity" id="editQty" value="<?php echo $data['quantity']; ?>" oninput="calc()">
            
            
            <label>Unit Price</label>
            <input type="number" name="unit_price" id="editPrice" value="<?php echo $data['unit_price']; ?>" oninput="calc()">
            
            <div class="input-group">
    <label>Size</label>
    <input type="hidden" name="size" id="selectedSize" value="<?php echo $data['size']; ?>">
    
    <div class="size-options">
        <?php
        $sizes = ['S', 'M', 'L', 'XL' , '2XL'];
        foreach ($sizes as $s) {
            // If the size matches the database, add the 'active' class
            $activeClass = ($data['size'] == $s) ? 'active' : '';
            echo "<button type='button' class='$activeClass' onclick=\"setSize('$s', this)\">$s</button>";
        }
        ?>
    </div>
</div>

            <div class="total-section">
                <strong>New Total: ₱<span id="editTotal"><?php echo number_format($data['total_amount'], 2); ?></span></strong>
            </div>

            <button type="submit" class="submit-btn">UPDATE RECORD</button>
            <a href="sales_records.php" style="text-decoration:none; color:grey;">Cancel</a>


            
        </form>
    </div>

    <script>
        function calc() {
            let q = document.getElementById('editQty').value;
            let p = document.getElementById('editPrice').value;
            document.getElementById('editTotal').innerText = (q * p).toLocaleString()
        }

        
    // 1. Function to handle the size button clicks (Moved OUTSIDE)
    function setSize(size, btnElement) {
        // Update the hidden input value
        document.getElementById('selectedSize').value = size;

        // Remove 'active' class from all buttons in the group
        const buttons = document.querySelectorAll('.size-options button');
        buttons.forEach(btn => btn.classList.remove('active'));

        // Add 'active' class to the clicked button
        btnElement.classList.add('active');
    }

    // 2. Function to calculate the total
    function calc() {
        let q = document.getElementById('editQty').value || 0;
        let p = document.getElementById('editPrice').value || 0;
        let total = q * p;
        
        // Update the visual text with formatting
        document.getElementById('editTotal').innerText = total.toLocaleString('en-PH', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }
</script>
   
</body>
</html>