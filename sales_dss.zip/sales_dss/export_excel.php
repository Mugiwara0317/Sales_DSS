<?php
include 'db_config.php';

// 1. Capture Filters (Same as your Reports and PDF page)
$selected_channel = $_GET['channel'] ?? 'All Channels';
$selected_brand = $_GET['brand'] ?? 'All Brands';

$where_clauses = ["1=1"]; 
if ($selected_channel !== 'All Channels') {
    $where_clauses[] = "channel = '" . $conn->real_escape_string($selected_channel) . "'";
}
if ($selected_brand !== 'All Brands') {
    $where_clauses[] = "brand = '" . $conn->real_escape_string($selected_brand) . "'";
}
$where_sql = implode(" AND ", $where_clauses);

// 2. Set Headers to force download as Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=ShirtToGo_Sales_Report_" . date('Y-m-d') . ".xls");
header("Pragma: no-cache");
header("Expires: 0");

// 3. Fetch Data
$sales_report = $conn->query("SELECT * FROM sales_records WHERE $where_sql ORDER BY transaction_date DESC");

// 4. Create the Excel Table Output
echo '<table border="1">';
echo '<tr><th colspan="5" style="background-color: #1a0a54; color: white; font-size: 16px;">SHIRT TO GO SALES REPORT</th></tr>';
echo '<tr><th colspan="5">Filters: Brand: ' . $selected_brand . ' | Channel: ' . $selected_channel . '</th></tr>';
echo '<tr>
        <th style="background-color: #f0eeff;">Date</th>
        <th style="background-color: #f0eeff;">Brand Name</th>
        <th style="background-color: #f0eeff;">Quantity Sold</th>
        <th style="background-color: #f0eeff;">Total Sales</th>
        <th style="background-color: #f0eeff;">Sales Channel</th>
      </tr>';

$total_revenue = 0;
$total_qty = 0;

while($row = $sales_report->fetch_assoc()) {
    $total_revenue += $row['total_amount'];
    $total_qty += $row['quantity'];
    
    echo '<tr>';
    echo '<td>' . date('M d, Y', strtotime($row['transaction_date'])) . '</td>';
    echo '<td>' . $row['brand'] . '</td>';
    echo '<td>' . $row['quantity'] . '</td>';
    echo '<td>' . number_format($row['total_amount'], 2) . '</td>';
    echo '<td>' . $row['channel'] . '</td>';
    echo '</tr>';
}

// 5. Add Summary Row at the Bottom
echo '<tr style="font-weight: bold; background-color: #eee;">';
echo '<td colspan="2" align="right">GRAND TOTAL:</td>';
echo '<td>' . $total_qty . '</td>';
echo '<td>' . number_format($total_revenue, 2) . '</td>';
echo '<td></td>';
echo '</tr>';
echo '</table>';
?>