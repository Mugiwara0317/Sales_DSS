<?php
require_once 'dompdf/autoload.inc.php'; // Adjust path if necessary
use Dompdf\Dompdf;
use Dompdf\Options;

include 'db_config.php';

// 1. Capture the same filters as the reports page
$selected_channel = $_GET['channel'] ?? 'All Channels';
$selected_brand = $_GET['brand'] ?? 'All Brands';

$where_clauses = ["1=1"]; 
if ($selected_channel !== 'All Channels') {
    $where_clauses[] = "channel = '" . $conn->real_escape_string($selected_channel) . "'";
}
if ($selected_brand !== 'All Brands') {
    $where_clauses[] = "brand = '" . $conn->real_escape_string($selected_brand) . "'";
}
$where_sql = implode(" AND ", $where_clauses);

// 2. Fetch Data
$sales_report = $conn->query("SELECT * FROM sales_records WHERE $where_sql ORDER BY transaction_date DESC");

// 3. Start building the HTML for the PDF
$html = '
<style>
    body { font-family: sans-serif; color: #1a0a54; }
    .header { text-align: center; margin-bottom: 30px; }
    .title { font-size: 24px; font-weight: bold; }
    .filters { margin-bottom: 20px; font-size: 12px; color: #6a5eff; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th { background-color: #f0eeff; padding: 10px; text-align: left; font-size: 12px; border-bottom: 2px solid #1a0a54; }
    td { padding: 10px; border-bottom: 1px solid #eee; font-size: 11px; }
    .total-row { font-weight: bold; background-color: #f8f9fa; }
</style>

<div class="header">
    <div class="title">Shirt To Go - Sales Report</div>
    <div class="filters">Channel: '.$selected_channel.' | Brand: '.$selected_brand.'</div>
</div>

<table>
    <thead>
        <tr>
            <th>Date</th>
            <th>Brand Name</th>
            <th>Quantity</th>
            <th>Total Sales</th>
            <th>Channel</th>
        </tr>
    </thead>
    <tbody>';

while($row = $sales_report->fetch_assoc()) {
    $html .= '
        <tr>
            <td>'.date('M d, Y', strtotime($row['transaction_date'])).'</td>
            <td>'.$row['brand'].'</td>
            <td>'.$row['quantity'].' pcs</td>
            <td>₱'.number_format($row['total_amount'], 2).'</td>
            <td>'.$row['channel'].'</td>
        </tr>';
}

$html .= '</tbody></table>';

// 4. Initialize Dompdf
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// 5. Output to browser
$dompdf->stream("Shirt_To_Go_Report.pdf", ["Attachment" => false]);
?>