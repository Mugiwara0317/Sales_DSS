<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.html");
    exit();
}

include 'db_config.php';

// Check if the form was submitted via the "Save / Update" button
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_inventory'])) {
    
    // Sanitize inputs to prevent SQL injection
    $brand_name = $conn->real_escape_string($_POST['brand_name']);
    $size = $conn->real_escape_string($_POST['selected_size']);
    $stock_qty = intval($_POST['current_stock']);
    $reorder_lvl = intval($_POST['reorder_level']);

    // Check if this brand already exists in your database
    $check_brand = $conn->query("SELECT id FROM inventory WHERE brand = '$brand_name' AND size = '$size'");

    if ($check_brand->num_rows > 0) {
        // If it exists, UPDATE the quantity by adding the new stock
        $sql = "UPDATE inventory 
                SET stock_quantity = stock_quantity + $stock_qty, 
                    reorder_level = $reorder_lvl 
                WHERE brand = '$brand_name' AND size = '$size'";
    } else {
        // If it's a new brand, INSERT a new record matching your structure
        $sql = "INSERT INTO inventory (brand, size, stock_quantity, reorder_level) 
                VALUES ('$brand_name', '$size', $stock_qty, $reorder_lvl)";
    }

    if ($conn->query($sql)) {
        // Refresh the page to update the KPI cards and Table
        header("Location: inventory.php?success=1");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}

// Get Search Term
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

// Fetch KPI Data
$total_items = $conn->query("SELECT SUM(stock_quantity) as total FROM inventory")->fetch_assoc()['total'] ?? 0;
$total_brands = $conn->query("SELECT COUNT(DISTINCT brand) as total FROM inventory")->fetch_assoc()['total'] ?? 0;
$low_stock_count = $conn->query("SELECT COUNT(*) as total FROM inventory WHERE stock_quantity < 10")->fetch_assoc()['total'] ?? 0;

// Fetch Inventory for Grid and Table
$sql = "SELECT * FROM inventory";
if (!empty($search)) {
    $sql .= " WHERE brand LIKE '%$search%'";
}
$sql .= " ORDER BY brand ASC";
$inventory_result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory - Shirt To Go</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="inventory-style.css">
    
</head>
<body>

    <header class="main-header">
        <div class="header-container">
            <div class="logo-section">
                <img src="images/logo.png" alt="Logo" class="nav-logo">
            </div>
            <nav class="nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="sales_records.php">Sales Records</a>
                <a href="inventory.php" class="active">Inventory</a>
                <a href="reports.php">Reports</a>
            </nav>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </header>

    <main class="dashboard-content">
        <div class="page-title">
            <h1>Inventory Management</h1>
            <p>Track stock levels and manage items</p>
        </div>

        <div class="kpi-grid">
            <div class="card">
                <h3>Total Items</h3>
                <p class="value"><?php echo number_format($total_items); ?></p>
            </div>
            <div class="card">
                <h3>Total Brands</h3>
                <p class="value"><?php echo $total_brands; ?></p>
            </div>
            <div class="card">
                <h3>Low Stock Items</h3>
                <p class="value"><?php echo $low_stock_count; ?></p>
            </div>
        </div>

        <div class="brand-inventory-header">
            <h2 style="color: #1a0a54; font-weight: 800; font-size: 1.4rem;">Brand Inventory / Stock Status</h2>
            <form method="GET" class="search-box">
                <i class="fa fa-search" style="color: #1a0a54;"></i>
                <input type="text" name="search" placeholder="Search Brand..." value="<?php echo htmlspecialchars($search); ?>">
            </form>
        </div>

        <div class="brand-grid">
            <?php if ($inventory_result->num_rows > 0): ?>
                <?php while($row = $inventory_result->fetch_assoc()): 
                    $isLow = ($row['stock_quantity'] < 10);
                ?>
                    <div class="brand-card">
                        <span class="status-badge <?php echo $isLow ? 'badge-low' : 'badge-instock'; ?>">
                            <?php echo $isLow ? 'Low Stock' : 'In Stock'; ?>
                        </span>
                        <div class="brand-name"><?php echo htmlspecialchars($row['brand']); ?></div>
                        <div class="stock-info">
                            <span class="stock-label">Stock Qty:</span> 
                            <span class="stock-value"><?php echo $row['stock_quantity']; ?> units</span>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="no-data" style="grid-column: 1/-1; text-align: center; padding: 20px;">
                    <p>No brands found in inventory.</p>
                </div>
            <?php endif; ?>
        </div>

        <div class="inventory-table-container" style="background: white; padding: 30px; border-radius: 15px; margin-top: 40px; box-shadow: 0 4px 12px rgba(0,0,0,0.06);">
            <div class="brand-inventory-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                <h2 style="color: #1a0a54; font-weight: 800; font-size: 1.4rem;">Brand Inventory / Stock Status</h2>
                <button onclick="openStockModal()" class="add-sale-btn" style="background: #6a5eff; color: white; border: none; padding: 10px 20px; border-radius: 8px; font-weight: bold; cursor: pointer;">
                    Add new Stock
                </button>
            </div>

            <table style="width: 100%; border-collapse: collapse; text-align: left;">
                <thead>
                    <tr style="border-bottom: 2px solid #f0f0f0; color: #4a5568; font-size: 0.9rem;">
                        <th style="padding: 15px 10px;">Brand Name</th>
                        <th style="padding: 15px 10px; text-align: center;">Stock Quantity</th>
                        <th style="padding: 15px 10px; text-align: center;">Reorder Level</th>
                        <th style="padding: 15px 10px; text-align: right;">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $inventory_result = $conn->query("SELECT * FROM inventory LIMIT 8");
                    while($row = $inventory_result->fetch_assoc()): 
                        $isLow = ($row['stock_quantity'] <= ($row['reorder_level'] ?? 10));
                    ?>
                    <tr style="border-bottom: 1px solid #f8f8f8; font-size: 0.95rem; color: #1a0a54; font-weight: 500;">
                        <td style="padding: 15px 10px;"><?php echo htmlspecialchars($row['brand']); ?></td>
                        <td style="padding: 15px 10px; text-align: center;"><?php echo $row['stock_quantity']; ?></td>
                        <td style="padding: 15px 10px; text-align: center; color: #a0aec0;"><?php echo $row['reorder_level'] ?? '10'; ?></td>
                        <td style="padding: 15px 10px; text-align: right;">
                            <span class="status-badge <?php echo $isLow ? 'badge-low' : 'badge-instock'; ?>" style="position: relative; top: 0; right: 0; display: inline-block;">
                                <?php echo $isLow ? 'Low Stock' : 'In Stock'; ?>
                            </span>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>

    <div id="stockModal" class="modal-overlay">
        <div class="custom-modal">
            <h1 class="modal-title">Inventory</h1>
            <form method="POST">
                <div class="input-field">
                    <label>Brand Name</label>
                    <input type="text" name="brand_name" id="modal_brand" class="styled-input" placeholder="Enter Brand Name" required>
                </div>
                <div class="input-field">
                    <label>Size</label>
                    <div class="size-selector">
                        <button type="button" class="size-btn">S</button>
                        <button type="button" class="size-btn active">M</button>
                        <button type="button" class="size-btn">L</button>
                        <button type="button" class="size-btn">XL</button>
                    </div>
                    <input type="hidden" name="selected_size" id="selected_size" value="M">
                </div>
                <div class="input-field">
                    <label>Current Stock</label>
                    <input type="number" name="current_stock" id="modal_stock" class="styled-input" value="0" required>
                </div>
                <div class="input-field">
                    <label>Reorder Level</label>
                    <input type="number" name="reorder_level" id="modal_reorder" class="styled-input" value="10" required>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="save_inventory" class="btn-save">Save / Update</button>
                    <button type="button" class="btn-cancel" onclick="closeStockModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openStockModal() {
            document.getElementById('stockModal').style.display = 'flex';
        }

        function closeStockModal() {
            document.getElementById('stockModal').style.display = 'none';
        }

        // Handle size button toggling
        document.querySelectorAll('.size-btn').forEach(button => {
            button.addEventListener('click', function() {
                document.querySelectorAll('.size-btn').forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
                document.getElementById('selected_size').value = this.innerText;
            });
        });

        // Close modal when clicking outside
        window.onclick = function(event) {
            let modal = document.getElementById('stockModal');
            if (event.target == modal) {
                closeStockModal();
            }
        }
    </script>
</body>
</html>