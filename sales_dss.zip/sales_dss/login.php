<?php
session_start();

// 1. Database Connection
$host = "localhost";
$db_user = "root";     
$db_pass = "";         
$db_name = "shirt_to_go_db";

$conn = mysqli_connect($host, $db_user, $db_pass, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// 2. Handle Login
if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) === 1) {
        $_SESSION['user'] = $username;
        echo "<script>alert('Login Successful!'); window.location='dashboard.php';</script>";
    } else {
        echo "<script>alert('Invalid Username or Password'); window.location='login.html';</script>";
    }
}
?>