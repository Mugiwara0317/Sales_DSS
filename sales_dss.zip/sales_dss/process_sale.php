<?php
include 'db_config.php';

// Capture form data from your Sales Record entry
$brand = $_POST['brand'];
$quantity = intval($_POST['quantity']);
$price = $_POST['total_amount'];
$channel = $_POST['channel'];
$date = $_POST['transaction_date'];

// Start Transaction
$conn->begin_transaction();

try {
    // 1. Check current stock level
    $check_stock = $conn->prepare("SELECT stock_quantity FROM inventory WHERE brand = ?");
    $check_stock->bind_param("s", $brand);
    $check_stock->execute();
    $result = $check_stock->get_result();
    $item = $result->fetch_assoc();

    if (!$item || $item['stock_quantity'] < $quantity) {
        throw new Exception("Insufficient stock for $brand!");
    }

    // 2. Insert Sale Record
    $stmt1 = $conn->prepare("INSERT INTO sales_records (brand, quantity, total_amount, channel, transaction_date) VALUES (?, ?, ?, ?, ?)");
    $stmt1->bind_param("sidss", $brand, $quantity, $price, $channel, $date);
    $stmt1->execute();

    // 3. Deduct from Inventory
    $stmt2 = $conn->prepare("UPDATE inventory SET stock_quantity = stock_quantity - ? WHERE brand = ?");
    $stmt2->bind_param("is", $quantity, $brand);
    $stmt2->execute();

    // If both worked, commit to database
    $conn->commit();
    header("Location: sales_records.php?success=1");

} catch (Exception $e) {
    // If anything failed, undo everything
    $conn->rollback();
    echo "Error: " . $e->getMessage();
}
?>