<?php
// 1. SESSION AND DATABASE (MUST BE AT THE VERY TOP)
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.html");
    exit();
}
include 'db_config.php';

// 2. PAGINATION SETTINGS
$limit = 10; 
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// 3. CAPTURE FILTERS
$report_type = $_GET['report_type'] ?? 'Monthly';
$period = $_GET['period'] ?? 'January 2026';
$selected_channel = $_GET['channel'] ?? 'All Channels';
$selected_brand = $_GET['brand'] ?? 'All Brands';

// 4. DYNAMIC DROPDOWN OPTIONS
$brands_list = $conn->query("SELECT DISTINCT brand FROM sales_records ORDER BY brand ASC");
$channels_list = $conn->query("SELECT DISTINCT channel FROM sales_records WHERE channel IS NOT NULL ORDER BY channel ASC");

// 5. BUILD SQL WHERE CLAUSE
$where_clauses = ["1=1"]; 
if ($selected_channel !== 'All Channels') {
    $where_clauses[] = "channel = '" . $conn->real_escape_string($selected_channel) . "'";
}
if ($selected_brand !== 'All Brands') {
    $where_clauses[] = "brand = '" . $conn->real_escape_string($selected_brand) . "'";
}
// Apply date filter for Jan 2026 based on your structure
$where_clauses[] = "MONTH(transaction_date) = 1 AND YEAR(transaction_date) = 2026";
$where_sql = implode(" AND ", $where_clauses);

// 6. CALCULATE KPI DATA
// Total Sales Amount
$revenue_query = $conn->query("SELECT SUM(total_amount) as total FROM sales_records WHERE $where_sql");
$total_revenue = $revenue_query->fetch_assoc()['total'] ?? 0;

// Total Quantity Sold
$sold_query = $conn->query("SELECT SUM(quantity) as total FROM sales_records WHERE $where_sql");
$total_sold = $sold_query->fetch_assoc()['total'] ?? 0;

// Best-Selling Brand
$best_query = $conn->query("SELECT brand, SUM(quantity) as total_qty FROM sales_records WHERE $where_sql GROUP BY brand ORDER BY total_qty DESC LIMIT 1");
$best_brand = $best_query->fetch_assoc()['brand'] ?? "N/A";

// Slow-Moving Brand
$slow_query = $conn->query("SELECT brand, SUM(quantity) as total_qty FROM sales_records WHERE $where_sql GROUP BY brand ORDER BY total_qty ASC LIMIT 1");
$slow_brand = $slow_query->fetch_assoc()['brand'] ?? "N/A";

// 7. PAGINATION AND TABLE DATA
$total_res = $conn->query("SELECT COUNT(*) as count FROM sales_records WHERE $where_sql");
$total_records = $total_res->fetch_assoc()['count'] ?? 0;
$total_pages = ceil($total_records / $limit);

$sales_report = $conn->query("SELECT * FROM sales_records WHERE $where_sql ORDER BY transaction_date DESC LIMIT $limit OFFSET $offset");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Shirt To Go</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="inventory-style.css"> 
</head>
<body style="background-color: #f0eeff;"> 

    <header class="main-header">
        <div class="header-container">
            <div class="logo-section">
                <img src="images/logo.png" alt="Logo" class="nav-logo">
            </div>
            <nav class="nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="sales_records.php">Sales Records</a>
                <a href="inventory.php">Inventory</a>
                <a href="reports.php" class="active">Reports</a>
            </nav>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </header>

    <main class="dashboard-content">
        <div class="page-title" style="text-align: center; margin-top: 40px;">
            <h1 style="color: #1a0a54; font-size: 2.5rem; font-weight: 800;">Reporting & Analytics</h1>
            <p style="color: #6a5eff; font-weight: 500;">Comprehensive sales and performance reports</p>
        </div>

        <div class="filter-section" style="background: white; padding: 30px; border-radius: 15px; margin: 20px 0; box-shadow: 0 4px 12px rgba(0,0,0,0.05);">
            <h2 style="color: #1a0a54; font-weight: 800; margin-bottom: 25px; font-size: 1.5rem;">Filters</h2>
            <form method="GET" action="reports.php" id="filterForm" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px;">
                <div class="filter-group">
                    <label style="color: #8b80f9; font-weight: 600; display: block; margin-bottom: 10px;">Report Type</label>
                    <select name="report_type" class="filter-dropdown" onchange="this.form.submit()">
                        <option value="Daily" <?php if($report_type == 'Daily') echo 'selected'; ?>>Daily</option>
                        <option value="Weekly" <?php if($report_type == 'Weekly') echo 'selected'; ?>>Weekly</option>
                        <option value="Monthly" <?php if($report_type == 'Monthly') echo 'selected'; ?>>Monthly</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label style="color: #8b80f9; font-weight: 600; display: block; margin-bottom: 10px;">Period</label>
                    <select name="period" class="filter-dropdown" onchange="this.form.submit()">
                        <option value="January 2026" selected>January 2026</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label style="color: #8b80f9; font-weight: 600; display: block; margin-bottom: 10px;">Sales Channel</label>
                    <select name="channel" class="filter-dropdown" onchange="this.form.submit()">
                        <option value="All Channels">All Channels</option>
                        <?php while($c = $channels_list->fetch_assoc()): ?>
                            <option value="<?php echo $c['channel']; ?>" <?php if($selected_channel == $c['channel']) echo 'selected'; ?>>
                                <?php echo $c['channel']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="filter-group">
                    <label style="color: #8b80f9; font-weight: 600; display: block; margin-bottom: 10px;">Brand</label>
                    <select name="brand" class="filter-dropdown" onchange="this.form.submit()">
                        <option value="All Brands">All Brands</option>
                        <?php while($b = $brands_list->fetch_assoc()): ?>
                            <option value="<?php echo $b['brand']; ?>" <?php if($selected_brand == $b['brand']) echo 'selected'; ?>>
                                <?php echo $b['brand']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </form>
            <div style="margin-top: 25px; display: flex; gap: 12px;">
                <span class="filter-tag"><?php echo $report_type; ?></span>
                <span class="filter-tag"><?php echo $selected_channel; ?></span>
                <span class="filter-tag"><?php echo $selected_brand; ?></span>
            </div>
        </div>

        <div class="kpi-grid-new" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-top: 25px;">
            <div class="report-card">
                <div class="card-icon-box"><i class="fa-solid fa-chart-line"></i></div>
                <div class="card-info">
                    <span class="card-label">Total Sales Amount</span>
                    <h2 class="card-value">₱<?php echo number_format($total_revenue); ?></h2>
                </div>
            </div>
            <div class="report-card">
                <div class="card-icon-box"><i class="fa-solid fa-chart-line"></i></div>
                <div class="card-info">
                    <span class="card-label">Total Quantity Sold</span>
                    <h2 class="card-value"><?php echo number_format($total_sold); ?> pcs</h2>
                </div>
            </div>
            <div class="report-card">
                <div class="card-icon-box"><i class="fa-solid fa-chart-line"></i></div>
                <div class="card-info">
                    <span class="card-label">Best-Selling Brand</span>
                    <h2 class="card-value"><?php echo htmlspecialchars($best_brand); ?></h2>
                </div>
            </div>
            <div class="report-card">
                <div class="card-icon-box"><i class="fa-solid fa-chart-line"></i></div>
                <div class="card-info">
                    <span class="card-label">Slow-Moving Brand</span>
                    <h2 class="card-value"><?php echo htmlspecialchars($slow_brand); ?></h2>
                </div>
            </div>
        </div>

        <div class="sales-records-container" style="background: white; padding: 30px; border-radius: 15px; margin-top: 30px; box-shadow: 0 4px 12px rgba(0,0,0,0.06);">
            <div class="table-header" style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 25px;">
                <div>
                    <h2 style="color: #1a0a54; font-weight: 800; font-size: 1.5rem; margin: 0;">Sales Records</h2>
                    <p style="color: #8b80f9; font-size: 0.9rem; margin-top: 5px;">Detailed transaction history by period</p>
                </div>
                <div class="export-actions" style="display: flex; gap: 10px;">
                    <a href="export_pdf.php?channel=<?php echo urlencode($selected_channel); ?>&brand=<?php echo urlencode($selected_brand); ?>" 
   target="_blank" 
   class="btn-dark-export" 
   style="text-decoration: none; display: inline-block;">
    Export to PDF
</a>
                    <a href="export_excel.php?channel=<?php echo urlencode($selected_channel); ?>&brand=<?php echo urlencode($selected_brand); ?>" 
   class="btn-dark-export" 
   style="text-decoration: none; display: inline-block;">
    Export to Excel
</a>
                    <button onclick="printReport()" class="btn-dark-export">
    <i class="fa fa-print"></i> Print Report
</button>
                </div>
            </div>
            <table class="report-table" style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="border-bottom: 2px solid #f0f0f0; text-align: left;">
                        <th style="padding: 15px 10px; color: #4a5568; font-size: 0.85rem;">Date / Period</th>
                        <th style="padding: 15px 10px; color: #4a5568; font-size: 0.85rem;">Brand Name</th>
                        <th style="padding: 15px 10px; color: #4a5568; font-size: 0.85rem; text-align: center;">Quantity Sold</th>
                        <th style="padding: 15px 10px; color: #4a5568; font-size: 0.85rem;">Total Sales</th>
                        <th style="padding: 15px 10px; color: #4a5568; font-size: 0.85rem; text-align: center;">Sales Channel</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $sales_report->fetch_assoc()): ?>
                    <tr style="border-bottom: 1px solid #f8f8f8;">
                        <td style="padding: 15px 10px; color: #1a0a54; font-weight: 500;">
                            <?php echo date('M d, Y', strtotime($row['transaction_date'])); ?>
                        </td>
                        <td style="padding: 15px 10px; color: #4a5568;"><?php echo htmlspecialchars($row['brand']); ?></td>
                        <td style="padding: 15px 10px; text-align: center; color: #4a5568;"><?php echo $row['quantity']; ?></td>
                        <td style="padding: 15px 10px; color: #1a0a54; font-weight: 700;">₱<?php echo number_format($row['total_amount'], 2); ?></td>
                        <td style="padding: 15px 10px; text-align: center;">
                            <?php 
                                $channel = $row['channel'];
                                $badge_class = strtolower(str_replace(' ', '-', $channel));
                            ?>
                            <span class="channel-badge <?php echo $badge_class; ?>"><?php echo $channel; ?></span>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <div class="table-footer" style="display: flex; justify-content: space-between; align-items: center; margin-top: 30px;">
                <p style="color: #a0aec0; font-size: 0.9rem;">
                    Showing <?php echo min($offset + 1, $total_records); ?> to <?php echo min($offset + $limit, $total_records); ?> of <?php echo $total_records; ?> records
                </p>
                <div class="pagination" style="display: flex; gap: 10px;">
                    <?php if($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>&channel=<?php echo $selected_channel; ?>&brand=<?php echo $selected_brand; ?>" class="btn-pagination prev" style="text-decoration: none;">Previous</a>
                    <?php else: ?>
                        <button class="btn-pagination prev" style="opacity: 0.5; cursor: not-allowed;">Previous</button>
                    <?php endif; ?>
                    <?php if($page < $total_pages): ?>
                        <a href="?page=<?php echo $page + 1; ?>&channel=<?php echo $selected_channel; ?>&brand=<?php echo $selected_brand; ?>" class="btn-pagination next" style="text-decoration: none;">Next</a>
                    <?php else: ?>
                        <button class="btn-pagination next" style="opacity: 0.5; cursor: not-allowed;">Next</button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

<style>
    /* SHARED STYLES */
    .filter-dropdown { width: 100%; padding: 12px 15px; background-color: #1e293b; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; appearance: none; background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e"); background-repeat: no-repeat; background-position: right 15px center; background-size: 15px; }
    .filter-tag { background: #1e293b; color: white; padding: 6px 18px; border-radius: 20px; font-size: 0.85rem; font-weight: 500; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
    .report-card { background: #f8f9fa; border-radius: 12px; padding: 20px; display: flex; align-items: center; gap: 15px; box-shadow: 0 2px 8px rgba(0,0,0,0.04); }
    .card-icon-box { background: #e6e6ff; color: #1a0a54; width: 45px; height: 45px; display: flex; align-items: center; justify-content: center; border-radius: 8px; font-size: 1.2rem; }
    .card-label { color: #8b80f9; font-size: 0.85rem; font-weight: 700; display: block; margin-bottom: 4px; }
    .card-value { color: #1a0a54; font-size: 1.6rem; font-weight: 800; margin: 0; }
    .btn-dark-export { background: #1e293b; color: white; border: none; padding: 8px 18px; border-radius: 6px; font-weight: 700; font-size: 0.85rem; cursor: pointer; }
    .channel-badge { padding: 4px 12px; border-radius: 15px; font-size: 0.75rem; font-weight: 700; display: inline-block; }
    .retail { background: #e0e7ff; color: #4338ca; }
    .wholesale { background: #f3e8ff; color: #7e22ce; }
    .lazada { background: #ffedd5; color: #ea580c; }
    .shopee { background: #fee2e2; color: #dc2626; }
    .tiktok-shop { background: #ccfbf1; color: #0d9488; }
    .btn-pagination { padding: 10px 30px; border-radius: 8px; font-weight: 700; border: none; cursor: pointer; }
    .btn-pagination.prev { background: #1e293b; color: white; }
    .btn-pagination.next { background: #818cf8; color: white; }

    @media print {
    /* Hide everything except the report content */
    .main-header, 
    .nav-links, 
    .logout-btn, 
    .filter-section, 
    .export-actions, 
    .pagination,
    .btn-pagination {
        display: none !important;
    }

    /* Reset background and layout for printing */
    body {
        background-color: white !important;
        margin: 0;
        padding: 0;
    }

    .dashboard-content {
        margin: 0 !important;
        padding: 0 !important;
    }

    /* Style the table for paper */
    .sales-records-container {
        box-shadow: none !important;
        margin: 0 !important;
        padding: 0 !important;
        width: 100%;
    }

    table {
        width: 100%;
        border: 1px solid #000;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        color: black !important;
    }

    /* Ensure colors appear if "Print Background Graphics" is off */
    .channel-badge {
        border: 1px solid #ccc !important;
        color: black !important;
        background: transparent !important;
    }
}
</style>
</body>
<script>
function printReport() {
    // Optional: Add a title or timestamp to the printout via JS if needed
    window.print();
}
</script>
</html>