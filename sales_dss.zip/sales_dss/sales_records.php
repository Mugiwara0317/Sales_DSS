
<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.html");
    exit();
}

include 'db_config.php';
?>

<?php if (isset($_GET['status']) && $_GET['status'] == 'success'): ?>
    <div style="background: #d1fae5; color: #065f46; padding: 15px; border-radius: 10px; margin-bottom: 20px; font-weight: 600;">
        <i class="fas fa-check-circle"></i> Sale record saved successfully!
    </div>
<?php endif; ?>

<?php
// Get Totals for KPI Cards
$kpi_query = "SELECT SUM(total_amount) as total_revenue, SUM(quantity) as total_qty FROM sales_records";
$kpi_result = $conn->query($kpi_query);
$kpi_data = $kpi_result->fetch_assoc();

$total_revenue = $kpi_data['total_revenue'] ?? 0;
$total_qty = $kpi_data['total_qty'] ?? 0;

$best_brand_query = "SELECT brand, SUM(quantity) as qty FROM sales_records GROUP BY brand ORDER BY qty DESC LIMIT 1";
$best_result = $conn->query($best_brand_query);
$best_brand_data = $best_result->fetch_assoc();
$best_brand = $best_brand_data['brand'] ?? "N/A";

// 2. Get Slow-Moving Brand (Lowest Quantity)
$slow_brand_query = "SELECT brand, SUM(quantity) as qty FROM sales_records GROUP BY brand ORDER BY qty ASC LIMIT 1";
$slow_result = $conn->query($slow_brand_query);
$slow_brand_data = $slow_result->fetch_assoc();
$slow_brand = $slow_brand_data['brand'] ?? "N/A";

?>

<?php
// ... existing KPI code ...

// Define all possible channels to ensure the chart shows 0 for empty ones
$channels = ['Retail', 'Wholesale', 'Lazada', 'Shopee', 'Tiktok'];
$channel_data = array_fill_keys($channels, 0);

// Fetch total amount per channel
$chart_query = "SELECT channel, SUM(total_amount) as total FROM sales_records GROUP BY channel";
$chart_result = $conn->query($chart_query);

while ($row = $chart_result->fetch_assoc()) {
    $channel_name = $row['channel'];
    if (array_key_exists($channel_name, $channel_data)) {
        $channel_data[$channel_name] = (float)$row['total'];
    }
}

// Convert to a simple array of values for JavaScript
$chart_values = array_values($channel_data);
?>

<?php if (isset($_GET['status']) && $_GET['status'] == 'updated'): ?>
    <div style="background: #e0f2fe; color: #0369a1; padding: 15px; border-radius: 10px; margin: 20px; font-weight: 600;">
        <i class="fas fa-info-circle"></i> Transaction updated successfully!
    </div>
<?php endif; ?>

<?php if (isset($_GET['status']) && $_GET['status'] == 'deleted'): ?>
    <div style="background: #fee2e2; color: #991b1b; padding: 15px; border-radius: 10px; margin-bottom: 20px; font-weight: 600;">
        <i class="fas fa-trash-alt"></i> Transaction deleted successfully.
    </div>
<?php endif; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Records - Shirt To Go</title>
    <link rel="stylesheet" href="dashboard-style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

    <header class="main-header">
        <div class="header-container">
            <div class="logo-section">
                <img src="images/logo.png" alt="Logo" class="nav-logo">
            </div>
            <nav class="nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="sales_records.php" class="active">Sales Records</a>
                <a href="inventory.php">Inventory</a>
                <a href="reports.php">Reports</a>
            </nav>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </header>


    

    <main class="dashboard-content">
        <div class="page-title">
            <h1>Sales Records</h1>
            <p>View and manage all recorded sales transactions</p>
        </div>

        <div class="search-container">
    <form method="GET" action="sales_records.php" class="search-box">
        <i class="fas fa-search"></i>
        <input type="text" name="search" placeholder="Search by Transaction ID, Brand, or Channel" 
               value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
        <button type="submit" style="display:none;">Search</button>
    </form>
</div>

        <div class="kpi-grid">
            <div class="card">
                <h3>Total Sales Amount</h3>
                <p class="value">₱<?php echo number_format($total_revenue, 2); ?></p>
            </div>
            <div class="card">
                <h3>Total Quantity Sold</h3>
                <p class="value"><?php echo number_format($total_qty); ?></p>
            </div>
            <div class="card">
                <h3>Best-Selling Brand</h3>
                <p class="value brand"><?php echo htmlspecialchars($best_brand); ?></p>
            </div>
            <div class="card">
                <h3>Slow-Moving Brand</h3>
                <p class="value brand"><?php echo htmlspecialchars($slow_brand); ?></p>
            </div>
        </div>

        <div class="sales-trend-section">
            <div class="full-width-card">
                <h2 class="section-title-alt">Sales Trend Overview (by Channel)</h2>
                <div class="chart-container" style="position: relative; height:350px; width:100%">
                    <canvas id="channelTrendChart"></canvas>
                </div>
            </div>


        <div class="transactions-section">
    <div class="full-width-card">
        <div class="transaction-header">
            <h2 class="section-title-alt">Transaction</h2>
            <button class="add-sale-btn" onclick="openModal()">Add new Sale</button>
        </div>

     
        <div class="table-responsive">
    <table class="transaction-table">
        <thead>
            <tr>
                <th>Transaction ID</th>
                <th>Date</th>
                <th>Brand</th>
                <th>Size</th>
                <th>Qty</th>
                <th>Unit Price</th>
                <th>Total Amount</th>
                <th>Channel</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
include 'db_config.php';

// 1. Get the search term from the URL (if it exists)
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

// 2. Adjust SQL based on whether the user is searching
if (!empty($search)) {
    // Look for matches in ID, Brand, or Channel
    $sql = "SELECT * FROM sales_records 
            WHERE transaction_id LIKE '%$search%' 
            OR brand LIKE '%$search%' 
            OR channel LIKE '%$search%' 
            ORDER BY id DESC";
} else {
    // Default view: Show everything
    $sql = "SELECT * FROM sales_records ORDER BY id DESC";
}

$result = $conn->query($sql);



if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['transaction_id'] . "</td>";
        echo "<td>" . date('M d, Y', strtotime($row['transaction_date'])) . "</td>";
        echo "<td>" . $row['brand'] . "</td>";
        echo "<td>" . $row['size'] . "</td>";
        echo "<td>" . $row['quantity'] . "</td>";
        echo "<td>₱" . number_format($row['unit_price'], 2) . "</td>";
        echo "<td><strong>₱" . number_format($row['total_amount'], 2) . "</strong></td>";
        echo "<td>" . $row['channel'] . "</td>";
        echo "<td>
                <a href='edit_sale.php?id=" . $row['id'] . "' class='edit-link'>Edit</a> 
                <a href='delete_sale.php?id=" . $row['id'] . "' 
                   class='delete-link' 
                   style='color: #ef4444; margin-left: 10px;' 
                   onclick='return confirm(\"Are you sure you want to delete this transaction?\")'>
                   Delete
                </a>
              </td>";
        echo "</tr>";
    }
} else {
    // Show a "Not Found" message if the search returns 0 rows
    $message = !empty($search) ? "No results found for '" . htmlspecialchars($search) . "'" : "No transactions found";
    echo "<tr><td colspan='9' style='text-align:center;'>$message</td></tr>";
}
?>
        </tbody>
    </table>
</div>
            </table>
        </div>
    </div>
</div>

        <script>
        // Use DOMContentLoaded to ensure the element exists before targeting it
       document.addEventListener('DOMContentLoaded', function() {
    const canvasElement = document.getElementById('channelTrendChart');
    
    if (canvasElement) {
        const ctx = canvasElement.getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Retail', 'Wholesale', 'Lazada', 'Shopee', 'Tiktok'],
                datasets: [{
                    label: 'Sales per Channel',
                    // Use PHP to echo the array as a JSON string
                    data: <?php echo json_encode($chart_values); ?>,
                    backgroundColor: '#1a1f36',
                    borderRadius: 5,
                    barThickness: 60
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { 
                        beginAtZero: true,
                        // Remove the hardcoded 'max' and 'stepSize' to let Chart.js auto-scale
                        grid: { borderDash: [2, 2], color: '#e0e0e0' },
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toLocaleString();
                            }
                        }
                    },
                    x: {
                        grid: { display: false }
                    }
                }
            }
        });
    }
});

        function openModal() {
    document.getElementById("salesModal").style.display = "block";
}

function closeModal() {
    document.getElementById("salesModal").style.display = "none";
}

// Close if user clicks outside the modal box
window.onclick = function(event) {
    let modal = document.getElementById("salesModal");
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

// Function to handle Size selection buttons
function setSize(size, btnElement) {
    // 1. Update the hidden input value for the database
    document.getElementById('selectedSize').value = size;

    // 2. Remove 'active' class from all buttons
    const buttons = document.querySelectorAll('.size-options button');
    buttons.forEach(btn => btn.classList.remove('active'));

    // 3. Add 'active' class to the clicked button
    btnElement.classList.add('active');
}

// Add this inside your calculateTotal() JS function 
// to ensure the hidden input is also updated for the PHP POST
function calculateTotal() {
    const qty = parseFloat(document.getElementById('calcQty').value) || 0;
    const price = parseFloat(document.getElementById('calcPrice').value) || 0;
    const total = qty * price;

    // Update the visual text
    document.getElementById('displayTotal').innerText = "₱" + total.toLocaleString('en-PH', {
        minimumFractionDigits: 2
    });

    // OPTIONAL: Add a hidden input to your form to pass the total directly
    // <input type="hidden" name="total_amount" id="hiddenTotal">
    if(document.getElementById('hiddenTotal')) {
        document.getElementById('hiddenTotal').value = total;
    }

    
}


        </script>
        
    </main>

    <div id="salesModal" class="modal-overlay">
    <div class="modal-content">
        <span class="close-modal" onclick="closeModal()">&times;</span>
        <h2 class="modal-title">Sales Input Form</h2>
        
        <form id="addSaleForm" action="save_sale.php" method="POST">
    <div class="form-grid">
        <div class="form-column">
            <h3>Basic Transaction Information</h3>
            <div class="input-group">
    <label>Transaction ID</label>
    <?php 
        include 'db_config.php';
        
        // 1. Get the latest ID from the database
        $query = "SELECT transaction_id FROM sales_records ORDER BY id DESC LIMIT 1";
        $result = $conn->query($query);
        
        $next_number = 1; // Default starting number

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $last_id = $row['transaction_id']; // e.g., "ID-0005"
            
            // 2. Extract numeric part. "ID-" is 3 characters, so start at index 3
            $last_number = (int) substr($last_id, 3); 
            $next_number = $last_number + 1;
        }

        // 3. Format to ID-000X
        $formatted_id = "ID-" . str_pad($next_number, 4, "0", STR_PAD_LEFT);
    ?>
    <input type="text" name="transaction_id" value="<?php echo $formatted_id; ?>" readonly>
</div>
            <div class="input-group">
                <label>Sales Channel</label>
                <select name="channel">
                    <option value="Tiktok">Tiktok</option>
                    <option value="Lazada">Lazada</option>
                    <option value="Shopee">Shopee</option>
                    <option value="Retail">Retail</option>
                    <option value="Wholesale">Wholesale</option> 
                </select>
            </div>
            <div class="input-group">
                <label>Date of Transaction</label>
                <input type="date" name="transaction_date" value="2026-01-14" required>
            </div>
        </div>

        <div class="form-column">
            <h3>Product Information</h3>
            <div class="input-group">
    <label>Shirt Brand</label>
    <select name="brand" class="form-control" required>
        <option value="" disabled selected>Select a brand from inventory</option>
        <?php
        // Fetch all unique brands from your inventory table
        $brand_query = $conn->query("SELECT brand, stock_quantity FROM inventory ORDER BY brand ASC");
        
        while($brand_row = $brand_query->fetch_assoc()):
            $brand_name = htmlspecialchars($brand_row['brand']);
            $current_stock = $brand_row['stock_quantity'];
            
            // Disable the option if stock is 0 to prevent "ghost" sales
            $disabled = ($current_stock <= 0) ? 'disabled' : '';
            $stock_label = ($current_stock <= 0) ? ' (Out of Stock)' : " ($current_stock available)";
        ?>
            <option value="<?php echo $brand_name; ?>" <?php echo $disabled; ?>>
                <?php echo $brand_name . $stock_label; ?>
            </option>
        <?php endwhile; ?>
    </select>
</div>
            <div class="input-group">
                <label>Size</label>
                <input type="hidden" name="size" id="selectedSize" value="M">
                <div class="size-options">
                    <button type="button" onclick="setSize('S', this)">S</button>
                    <button type="button" class="active" onclick="setSize('M', this)">M</button>
                    <button type="button" onclick="setSize('L', this)">L</button>
                    <button type="button" onclick="setSize('XL', this)">XL</button>
                    <button type="button" onclick="setSize('2XL', this)">2XL</button>
                </div>
            </div>
            <div class="row-inputs">
                <div class="input-group">
                    <label>Quantity</label>
                    <input type="number" name="quantity" id="calcQty" value="10" min="1" oninput="calculateTotal()">
                </div>
                <div class="input-group">
                    <label>Unit Price</label>
                    <input type="number" name="unit_price" id="calcPrice" value="100" min="0" oninput="calculateTotal()">
                </div>
            </div>
        </div>
    </div>

    <div class="total-section">
        <div class="total-label">
            <strong>Total Amount</strong><br>
            <span>Quantity × Unit Price</span>
        </div>
        <div class="total-value" id="displayTotal">₱</div>
    </div>

    <button type="submit" class="submit-btn">SUBMIT</button>
</form>


        
    </div>
</div>




</body>
</html>

