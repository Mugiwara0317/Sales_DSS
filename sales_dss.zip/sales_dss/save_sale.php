<?php
include 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Capture POST data from the form
    $transaction_id = $_POST['transaction_id'];
    $channel = $_POST['channel'];
    $transaction_date = $_POST['transaction_date'];
    $brand = $_POST['brand'];
    $size = $_POST['size']; 
    $quantity = intval($_POST['quantity']); // Ensure it is an integer
    $unit_price = $_POST['unit_price'];
    
    // 2. Calculate Total
    $total_amount = $quantity * $unit_price;

    // Start Transaction to sync both tables
    $conn->begin_transaction();

    try {
        // 3. Verify Stock Quantity first
        $check_sql = "SELECT stock_quantity FROM inventory WHERE brand = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $brand);
        $check_stmt->execute();
        $result = $check_stmt->get_result();
        $inv_data = $result->fetch_assoc();

        if (!$inv_data || $inv_data['stock_quantity'] < $quantity) {
            throw new Exception("Insufficient stock! Only " . ($inv_data['stock_quantity'] ?? 0) . " units available for $brand.");
        }

        // 4. Insert into sales_records
        $sql_sales = "INSERT INTO sales_records (transaction_id, channel, transaction_date, brand, size, quantity, unit_price, total_amount) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_sales = $conn->prepare($sql_sales);
        $stmt_sales->bind_param("sssssidd", $transaction_id, $channel, $transaction_date, $brand, $size, $quantity, $unit_price, $total_amount);
        $stmt_sales->execute();

        // 5. Deduct from inventory
        $sql_inventory = "UPDATE inventory SET stock_quantity = stock_quantity - ? WHERE brand = ?";
        $stmt_inv = $conn->prepare($sql_inventory);
        $stmt_inv->bind_param("is", $quantity, $brand);
        $stmt_inv->execute();

        // 6. Commit the transaction if both succeed
        $conn->commit();
        
        header("Location: sales_records.php?status=success");
        exit();

    } catch (Exception $e) {
        // Rollback changes if any step fails
        $conn->rollback();
        header("Location: sales_records.php?status=error&message=" . urlencode($e->getMessage()));
        exit();
    }
}
?>