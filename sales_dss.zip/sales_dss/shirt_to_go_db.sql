-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2026 at 01:46 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shirt_to_go_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `brand` varchar(50) DEFAULT NULL,
  `size` varchar(10) DEFAULT NULL,
  `stock_quantity` int(11) DEFAULT 0,
  `reorder_level` int(11) DEFAULT 20
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `brand`, `size`, `stock_quantity`, `reorder_level`) VALUES
(1, 'Softex', NULL, 150, 20),
(2, 'Yalex', NULL, 150, 20),
(3, 'Lifeline', NULL, 150, 20),
(4, 'Gildan', NULL, 150, 20),
(5, 'Dannon', NULL, 0, 20),
(6, 'BlueCorner', NULL, 150, 20),
(7, 'Kentucky', NULL, 150, 20),
(9, 'A||Z', NULL, 150, 20),
(10, 'Fruit of the Loom', NULL, 150, 20);

-- --------------------------------------------------------

--
-- Table structure for table `sales_records`
--

CREATE TABLE `sales_records` (
  `id` int(11) NOT NULL,
  `transaction_id` varchar(50) NOT NULL,
  `channel` varchar(50) DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `brand` varchar(50) DEFAULT NULL,
  `size` varchar(10) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `total_price` decimal(10,2) DEFAULT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_records`
--

INSERT INTO `sales_records` (`id`, `transaction_id`, `channel`, `transaction_date`, `brand`, `size`, `quantity`, `total_price`, `unit_price`, `total_amount`, `created_at`) VALUES
(2, 'ID--1768722259', 'Retail', '2026-01-12', 'Gildan', 'M', 10, NULL, 100.00, 1000.00, '2026-01-18 08:08:02'),
(3, 'ID--1768722258', 'Shopee', '2026-01-18', 'Gildan', 'S', 10, NULL, 250.00, 2500.00, '2026-01-18 08:10:16'),
(4, 'ID--1768722257', 'Retail', '2025-01-09', 'Softex', 'XL', 10, NULL, 250.00, 2500.00, '2026-01-18 08:18:10'),
(5, 'ID--1768722256', 'Lazada', '2026-01-30', 'Yalex', 'XL', 50, NULL, 150.00, 7500.00, '2026-01-18 08:18:46'),
(6, 'ID--1768722255', 'Shopee', '2025-10-08', 'Yalex', 'XL', 1000, NULL, 140.00, 140000.00, '2026-01-18 08:43:48'),
(8, 'ID--1768722254', 'Wholesale', '2025-11-12', 'ARTIX', '2XL', 500, NULL, 100.00, 50000.00, '2026-01-18 10:03:03'),
(9, 'ID--1768722253', 'Shopee', '2025-09-10', 'Gildan', 'S', 50, NULL, 80.00, 4000.00, '2026-01-18 13:14:47'),
(10, 'ID--1768722252', 'Tiktok', '2025-10-07', 'BLUE CORNER', '2XL', 150, NULL, 100.00, 15000.00, '2026-01-18 15:27:50'),
(11, 'ID--1768722251', 'Retail', '2025-07-09', 'Dannon', 'M', 5, NULL, 100.00, 500.00, '2026-01-18 16:03:30'),
(12, 'ID--1768722250', 'Tiktok', '2025-04-29', 'Dannon', 'M', 5, NULL, 120.00, 600.00, '2026-01-18 16:11:21');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales_records`
--
ALTER TABLE `sales_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `sales_records`
--
ALTER TABLE `sales_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
